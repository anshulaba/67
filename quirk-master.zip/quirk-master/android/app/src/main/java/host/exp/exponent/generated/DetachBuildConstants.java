package host.exp.exponent.generated;

// This file is auto-generated. Please don't rename!
public class DetachBuildConstants {

  public static final String DEVELOPMENT_URL = "exp4d07d66c4b23470393769aad813cee0c://192.168.86.40:19000";

}
